If the bootstrap version is updated, the newest version should be grabbed by running
* npm install bootstrap *

From here, you must recompile the custom css.
1. cd into the scss directory
2. run the command * sass custom.scss ../node_modules/bootstrap/css/bootstrap.css *

The above command will update the bootstrap files with custom settings (colors, fonts, etc.)